package com.jlt.main.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController()
//url:: http://localhost:8018/myrestapi
@RequestMapping("myrestapi")
public class HelloWorldController {
	// http://localhost:8018/myrestapi/message
	@RequestMapping("message")
	
	public String PrintMessage()
	{
		return "Hello world from spring boot";
	}

}
