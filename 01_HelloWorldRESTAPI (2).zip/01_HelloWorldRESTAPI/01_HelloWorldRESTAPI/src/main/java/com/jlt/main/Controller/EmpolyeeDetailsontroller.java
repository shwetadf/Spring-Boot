package com.jlt.main.Controller;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.jlt.main.Util.EmployeeCRUD;
import com.jlt.pojo.Employee;

@RestController()
//url:: http://localhost:8018/myrestapi
@RequestMapping("empolyeeapi")
public class EmpolyeeDetailsontroller {
	
	
	// http://localhost:8018/empolyeeapi/1
			@RequestMapping(value="{employeeId}",method=RequestMethod.GET)
	public Employee getEmployee(@PathVariable int employeeId) {
				
				EmployeeCRUD employeecrud=new EmployeeCRUD();
				Employee employee=employeecrud.getEmployee(employeeId);
		return employee;
		
	}
			// http://localhost:8018/empolyeeapi/employee
			@RequestMapping(value = "employee", method = RequestMethod.POST)
			public boolean addEmployee(@RequestBody Employee employee) {
				EmployeeCRUD employeeCRUD = new EmployeeCRUD();
				boolean result = employeeCRUD.addEmployee(employee);
				return result;
			}
			
			@RequestMapping(value = "allemployees", method = RequestMethod.GET)
			public ArrayList<Employee> getAllEmployees(@RequestBody Employee employee) {
				EmployeeCRUD employeeCRUD = new EmployeeCRUD();
				 return employeeCRUD.getAllEmployees();
				
			}
			
			
//			// http://localhost:8018/empolyeeapi/shweta
//			@RequestMapping(value="{name}",method=RequestMethod.POST)
//			public String getEmployee(@PathVariable String name) {
//				return "Employee details for EmployeeID::" +name;
//			}
	// http://localhost:8018/empolyeeapi/one
	/*	@RequestMapping(value="one",method=RequestMethod.GET)
		public String method1()
		{
			return "method1";
			
		}
		// http://localhost:8018/empolyeeapi/two
				@RequestMapping(value="two",method=RequestMethod.POST)
		public String method2()
		{
			return "method2";
		}
				// http://localhost:8018/empolyeeapi/three
				@RequestMapping(value="three",method=RequestMethod.PUT)
				public String method3()
				{
					return "method3";
				}
		
				// http://localhost:8018/empolyeeapi/four
				@RequestMapping(value="four",method=RequestMethod.DELETE)
				public String method4()
				{
					return "method4";
				}*/
		
}